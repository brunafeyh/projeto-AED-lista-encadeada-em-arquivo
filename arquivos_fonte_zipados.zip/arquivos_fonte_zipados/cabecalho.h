#ifndef CABECALHO_H
#define CABECALHO_H

typedef int tipoItem;

// cabecalho do arquivo
typedef struct {
    tipoItem pos_cabeca; //posição do início da lista
    tipoItem pos_topo; // 1a posição não usada no fim do arquivo
    tipoItem pos_livre; // posição do início da lista de nós livres
} CABECALHO;

void cria_lista_vazia(FILE* arq);
CABECALHO * le_cabecalho(FILE * arq);
void escreve_cabecalho(FILE* arq, CABECALHO* cab);


#endif //CABECALHO_H
