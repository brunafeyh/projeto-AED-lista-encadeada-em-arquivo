#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lote.h"
#include "curso.h"
#include "disciplina.h"
#include "professor.h"
#include "distribuicao.h"

//Faz a leitura das informa��es do curso no arquivo .txt e registra o curso no arquivo bin�rio de curso
//Pr�-condi��o: nenhuma
//P�s-condi��o: inser��o do curso no arquivo bin�rio
void registrar_lote_curso(FILE * file_lote, FILE * file_curso){
    GRADUACAO curso;

    fscanf(file_lote, "%d;", &curso.codigo);
    fscanf(file_lote, "%[^;]%*c", curso.nome);
    fscanf(file_lote, "%c%*c", &curso.area);

    inserir_curso_file(file_curso, curso);
}

//Faz a leitura das informa��es da disciplina no arquivo .txt e registra a disciplina no arquivo bin�rio de curso
//Pr�-condi��o: nenhuma
//P�s-condi��o: inser��o da disciplina no arquivo bin�rio
void registrar_lote_disciplina(FILE * file_lote, FILE * file_disciplina){
    DISCIPLINA disciplina;

    fscanf(file_lote, "%d;", &disciplina.codigo);
    fscanf(file_lote, "%[^;]%*c", disciplina.nome);
    fscanf(file_lote, "%d;", &disciplina.cod_curso);
    fscanf(file_lote, "%d%*c", &disciplina.serie);

    inserir_disciplina_file(file_disciplina, disciplina);
}

//Faz a leitura das informa��es do professor no arquivo .txt e registra o professor no arquivo bin�rio de curso
//Pr�-condi��o: nenhuma
//P�s-condi��o: inser��o do professor no arquivo bin�rio
void registrar_lote_professor(FILE * file_lote, FILE * file_professor){
    PROFESSOR professor;

    fscanf(file_lote, "%d;", &professor.codigo);
    fscanf(file_lote, "%[^\n]%*c", professor.nome);

    inserir_professor_file(file_professor, professor);
}

//Faz a leitura das informa��es da distribui��o no arquivo .txt e registra o curso no arquivo bin�rio de distribui��o
//Pr�-condi��o: nenhuma
//P�s-condi��o: inser��o da distribui��o no arquivo bin�rio
void registrar_lote_distribuicao(FILE * file_lote, FILE * file_distribuicao){
    DISTRIBUICAO distribuicao;

    fscanf(file_lote, "%d;", &distribuicao.cod_disciplina);
    fscanf(file_lote, "%d;", &distribuicao.ano_letivo);
    fscanf(file_lote, "%d%*c", &distribuicao.cod_professor);

    inserir_distribuicao_file(file_distribuicao, distribuicao);
}

//Insere informa��es de curso, disciplina, professor e distribui��o atrav�s de dados registrados em um determinados arquivo .txt
//Pr�-condi��o: nome do arquivo informado pelo usu�rio
//P�s-condi��o: inser��o de cada informa��o em seu respectivo arquivo bin�rio
void inserir_lote(ARQUIVOS files){
    FILE * file_lote;
    char nome_arquivo[50];

    do{
        printf("\n--> Digite o nome do arquivo a ser lido (sem '.txt'): ");
        scanf("%[^\n]%*c", nome_arquivo);
        strcat(nome_arquivo, ".txt");
        printf("%s\n", nome_arquivo);
        file_lote = fopen(nome_arquivo, "r");
    }while(file_lote == NULL);

    printf("\n--> Arquivo lido com sucesso...\n");

    char opcao;

    while(fscanf(file_lote, "%[^;]%*c", &opcao) != EOF){
        if(opcao == 'C'){
            registrar_lote_curso(file_lote, files.file_curso);
        }
        else if(opcao == 'D'){
            registrar_lote_disciplina(file_lote, files.file_disciplina);
        }
        else if(opcao == 'P'){
            registrar_lote_professor(file_lote, files.file_professor);
        }
        else if(opcao == 'M'){
            registrar_lote_distribuicao(file_lote, files.file_distribuicao);
        }
    }

    fclose(file_lote);
}
