#ifndef PROFESSOR_H
#define PROFESSOR_H
#define MAXS 51

typedef struct{
    int codigo;
    char nome[MAXS];
} PROFESSOR;

typedef struct{
    PROFESSOR professor;
    int prox;
} NO_PROFESSOR;

PROFESSOR ler_professor();
NO_PROFESSOR * le_no_professor(FILE* file_professor, int pos);
void escreve_no_professor(FILE* file_professor, NO_PROFESSOR * professor, int pos);
void inserir_professor_file(FILE* file_professor, PROFESSOR professor);
void imprimir_info_professor(NO_PROFESSOR no_professor);
void imprimir_lista_professor(FILE * file_professor);
NO_PROFESSOR buscar_professor_file(FILE * file_professor, int codigo);

#endif //PROFESSOR_H
