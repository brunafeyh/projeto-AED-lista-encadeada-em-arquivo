#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "curso.h"
#include "disciplina.h"
#include "professor.h"
#include "distribuicao.h"
#include "lote.h"

void header_menu(){
    printf(" ----------MENU---------\n");
    printf("| 1 - Cadastrar         |\n");
    printf("| 2 - Remover           |\n");
    printf("| 3 - Imprimir          |\n");
    printf("| 4 - Carregar arquivo  |\n");
    printf("| 5 - Encerrar programa |\n");
    printf(" ----------------------- \n");
}

void header_cadastrar(){
    printf(" ------------------CADASTRAR--------------- \n");
    printf("| 1 - Cadastrar curso                      |\n");
    printf("| 2 - Cadastrar disciplina                 |\n");
    printf("| 3 - Cadastrar professor                  |\n");
    printf("| 4 - Cadastrar distribuicao de disciplina |\n");
    printf("| 5 - Voltar ao menu principal             |\n");
    printf(" ------------------------------------------ \n");
}

void header_remover(){
    printf(" ------------------REMOVER--------------- \n");
    printf("| 1 - Remover distribuicao de disciplina |\n");
    printf("| 2 - Voltar ao menu principal           |\n");
    printf(" ---------------------------------------- \n");
}

void header_imprimir(){
    printf(" ---------------------------------IMPRIMIR-------------------------------- \n");
    printf("| 1 - Imprimir lista de cursos                                            |\n");
    printf("| 2 - Imprimir lista de disciplinas                                       |\n");
    printf("| 3 - Imprimir lista de professores                                       |\n");
    printf("| 4 - Imprimir lista de distribuicao de disciplina, organizadas por curso |\n");
    printf("| 5 - Voltar ao menu principal                                            |\n");
    printf(" ------------------------------------------------------------------------- \n");
}

void header_carregar_arquivo(){
    printf(" -----CARREGAR ARQUIVO---------- \n");
    printf("| 1 - Carregar arquivo de lote: |\n");
    printf("| 2 - Voltar ao menu principal  |\n");
    printf(" ------------------------------- \n");
}

void menu_cadastrar(ARQUIVOS files){
    GRADUACAO curso;
    DISCIPLINA disciplina;
    PROFESSOR professor;
    DISTRIBUICAO distribuicao;
    int opcao;

    header_cadastrar();
    printf("--> OPCAO: ");
    scanf("%d", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            curso = ler_curso();
            inserir_curso_file(files.file_curso, curso);
            printf("--> Curso registrado com sucesso!\n");
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 2:
            disciplina = ler_disciplina();
            inserir_disciplina_file(files.file_disciplina, disciplina);
            printf("--> Disciplina registrada com sucesso!\n");
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 3:
            professor = ler_professor();
            inserir_professor_file(files.file_professor, professor);
            printf("--> Professor registrado com sucesso!\n");
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 4:
            distribuicao = ler_distribuicao();
            inserir_distribuicao_file(files.file_distribuicao, distribuicao);
            printf("--> Distribuicao registrada com sucesso!\n");
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 5:
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_cadastrar(files);
            break;
    }
}

void menu_remover(ARQUIVOS files){
    int opcao, codigo, ano;

    header_remover();
    printf("--> OPCAO: ");
    scanf("%d", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            printf("\n--> Remover distribuicao de disciplina: \n");
            printf("--> Digite o codigo da disciplina que deseja remover:");
            scanf("%d", &codigo);
            printf("--> Digite o ano  letivo da disciplina que deseja remover:");
            scanf("%d", &ano);
            retira_distribuicao(files.file_distribuicao, codigo, ano);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 2:
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_remover(files);
            break;
    }
}

void menu_imprimir(ARQUIVOS files){
    int opcao;

    header_imprimir();
    printf("--> OPCAO: ");
    scanf("%d", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            imprimir_lista_cursos(files.file_curso);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 2:
            imprimir_lista_disciplinas(files);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 3:
            imprimir_lista_professor(files.file_professor);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 4:
            imprimir_lista_distribuicao(files);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 5:
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_imprimir(files);
            break;
    }
}

void menu_carregar_arquivo(ARQUIVOS files){
    int opcao;

    header_carregar_arquivo();
    printf("--> OPCAO: ");
    scanf("%d%*c", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            inserir_lote(files);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 2:
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_carregar_arquivo(files);
            break;
    }
}

void menu_principal(ARQUIVOS files){
    int opcao;
    header_menu();
    printf("--> OPCAO: ");
    scanf("%d", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            menu_cadastrar(files);
            break;
        case 2:
            menu_remover(files);
            break;
        case 3:
            menu_imprimir(files);
            break;
        case 4:
            menu_carregar_arquivo(files);
            break;
        case 5:
            printf("\n--> Encerrando programa\n\n");
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_principal(files);
            break;
    }
}
