#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "professor.h"
#include "cabecalho.h"
#include "file.h"

//Instancia uma struct PROFESSOR com as informações do professor que serão gravadas no arquivo
//Pré-condição: nenhuma
//Pós-condição: retorno é uma struct PROFESSOR
PROFESSOR ler_professor(){
    PROFESSOR professor;

    printf("\n--> CADASTRO DE PROFESSOR: \n");
    printf("Insira o codigo do professor: ");
    scanf("%d%*c", &professor.codigo);
    printf("Insira o nome do professor: ");
    scanf("%[^\n]%*c", professor.nome);

    return professor;
}

//lê um nó em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida da lista
//Pós-condição: ponteiro para nó lido é retornado
NO_PROFESSOR * le_no_professor(FILE* file_professor, int pos){
    NO_PROFESSOR * no_professor = malloc(sizeof(NO_PROFESSOR));
    fseek(file_professor, sizeof(CABECALHO)+ pos*sizeof(NO_PROFESSOR), SEEK_SET);
    fread(no_professor, sizeof(NO_PROFESSOR), 1, file_professor);
    return no_professor;
}

//Escreve um nó em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida do arquivo
//Pós-condição: nó escrito no arquivo
void escreve_no_professor(FILE* file_professor, NO_PROFESSOR * no_professor, int pos){
    fseek(file_professor, sizeof(CABECALHO)+ pos*sizeof(NO_PROFESSOR), SEEK_SET);
    fwrite(no_professor, sizeof(NO_PROFESSOR), 1, file_professor);
}

//Insere um nó contendo as informações do professor em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto
//Pós-condição: nó escrito no arquivo
void inserir_professor_file(FILE* file_professor, PROFESSOR professor){
    CABECALHO * cab = le_cabecalho(file_professor);
    NO_PROFESSOR no_professor;

    //Neste momento, criamos um nó do professor (contento os dados do professor)
    no_professor.professor.codigo = professor.codigo;
    strcpy(no_professor.professor.nome, professor.nome);

    //o item prox do no recebe o valor lido do cabeçalho do arquivo
   no_professor.prox = cab->pos_cabeca;

    if(cab->pos_livre == -1) { // não há nós livres, então usar o topo
        escreve_no_professor(file_professor, &no_professor, cab->pos_topo);
        cab->pos_cabeca = cab->pos_topo;
        cab->pos_topo++;
    }
    else { // usar nó da lista de livres
        NO_PROFESSOR  * aux = le_no_professor(file_professor, cab->pos_livre);
        escreve_no_professor(file_professor, &no_professor, cab->pos_livre);
        cab->pos_cabeca = cab->pos_livre;
        cab->pos_livre = aux->prox;
        free(aux);
    }
    escreve_cabecalho(file_professor, cab);
    free(cab);
}

//Imprime as informações de um determinado professor na tela
//Pré-condição: nenhuma
//Pós-condição: informações impressas na tela
void imprimir_info_professor(NO_PROFESSOR no_professor){
    printf("| %03d    ", no_professor.professor.codigo);
    printf("%-65s|\n", no_professor.professor.nome);
}

//Imprime as informações de todos os professores registrados, em uma lista
//Pré-condição: arquivo deve conter registros de curso
//Pós-condição: informações impressas na tela
void imprimir_lista_professor(FILE * file_professor){
    NO_PROFESSOR no_professor;

    if(!is_vazio(file_professor)){
        fseek(file_professor, sizeof(CABECALHO), SEEK_SET);

        printf(" --------------------------LISTA DE PROFESSORES----------------------------\n");
        printf("| COD.   NOME                                                             |\n");
        if(file_professor){
            while(fread(&no_professor, sizeof(NO_PROFESSOR), 1, file_professor) == 1){
                imprimir_info_professor(no_professor);
            }
        }
        printf(" --------------------------------------------------------------------------\n");
    }else{
        printf("\n--> Nao ha professores registrados!\n\n");
    }
}

//Localiza um curso através de seu código
//Pré-condição: nenhuma
//Pós-condição: as informações do professor são retornadas em uma struct do tipo NO_PROFESSOR
NO_PROFESSOR buscar_professor_file(FILE * file_professor, int codigo){
    NO_PROFESSOR no_professor;

    if(!is_vazio(file_professor)){
        fseek(file_professor, sizeof(CABECALHO), SEEK_SET);

        while(fread(&no_professor, sizeof(NO_PROFESSOR), 1, file_professor) == 1){
            if(no_professor.professor.codigo == codigo){
                return no_professor; //no momento em que encontra o código desejado, retorna as informações
            }
        }
    }

    return no_professor;
}
