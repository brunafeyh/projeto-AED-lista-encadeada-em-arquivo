#ifndef DISCIPLINA_H
#define DISCIPLINA_H
#define MAXS 51

#include "file.h"
#include "curso.h"

typedef struct{
    int codigo;
    char nome[MAXS];
    int cod_curso;
    int serie;
} DISCIPLINA;

typedef struct{
    DISCIPLINA disciplina;
    int prox;
} NO_DISCIPLINA;

DISCIPLINA ler_disciplina();
NO_DISCIPLINA * le_no_disciplina(FILE* file_disciplina, int pos);
void escreve_no_disciplina(FILE* file_disciplina, NO_DISCIPLINA * no_disciplina, int pos);
void inserir_disciplina_file(FILE* file_disciplina, DISCIPLINA disciplina);
void imprimir_info_disciplina(NO_DISCIPLINA no_disciplina, NO_CURSO no_curso);
void imprimir_lista_disciplinas(ARQUIVOS files);
NO_DISCIPLINA buscar_disciplina_file(FILE * file_disciplina, int codigo);

#endif //DISCIPLINA_H
